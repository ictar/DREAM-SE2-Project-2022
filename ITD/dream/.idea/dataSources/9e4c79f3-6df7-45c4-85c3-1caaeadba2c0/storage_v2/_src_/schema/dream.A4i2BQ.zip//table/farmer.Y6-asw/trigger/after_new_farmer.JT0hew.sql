create definer = root@localhost trigger after_new_farmer
    after insert
    on farmer
    for each row
BEGIN
    DECLARE fid int;
    select farmid into fid from farm where farmer=new.phonenumber;

    IF (exists (select * from farm where farmer=new.phonenumber)) THEN
        insert into farmer_farm (farm, farmer)
        values (fid, new.farmerid);
    END IF;

END;

